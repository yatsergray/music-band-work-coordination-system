package ua.yatsergray.backend.exception.band;

public class NoSuchChatAccessRoleException extends Exception {

    public NoSuchChatAccessRoleException(String message) {
        super(message);
    }
}
