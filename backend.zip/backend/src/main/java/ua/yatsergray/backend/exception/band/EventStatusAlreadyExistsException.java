package ua.yatsergray.backend.exception.band;

public class EventStatusAlreadyExistsException extends Exception {

    public EventStatusAlreadyExistsException(String message) {
        super(message);
    }
}
