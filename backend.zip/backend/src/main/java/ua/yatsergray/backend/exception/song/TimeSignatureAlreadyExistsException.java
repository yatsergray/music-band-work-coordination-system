package ua.yatsergray.backend.exception.song;

public class TimeSignatureAlreadyExistsException extends Exception {

    public TimeSignatureAlreadyExistsException(String message) {
        super(message);
    }
}
