package ua.yatsergray.backend.exception.band;

public class BandSongVersionConflictException extends Exception {

    public BandSongVersionConflictException(String message) {
        super(message);
    }
}
