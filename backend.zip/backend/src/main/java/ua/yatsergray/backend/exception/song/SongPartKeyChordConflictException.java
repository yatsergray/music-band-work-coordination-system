package ua.yatsergray.backend.exception.song;

public class SongPartKeyChordConflictException extends Exception {

    public SongPartKeyChordConflictException(String message) {
        super(message);
    }
}
