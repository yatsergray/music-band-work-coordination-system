package ua.yatsergray.backend.domain.type.band;

public enum StageRoleType {
    VOCAL,
    PIANO,
    ACOUSTIC_GUITAR,
    ELECTRIC_GUITAR,
    BASS_GUITAR,
    DRUMS
}
