package ua.yatsergray.backend.exception.song;

public class NoSuchSongPartDetailsException extends Exception {

    public NoSuchSongPartDetailsException(String message) {
        super(message);
    }
}
