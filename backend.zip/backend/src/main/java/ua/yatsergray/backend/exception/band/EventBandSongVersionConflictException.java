package ua.yatsergray.backend.exception.band;

public class EventBandSongVersionConflictException extends Exception {

    public EventBandSongVersionConflictException(String message) {
        super(message);
    }
}
