package ua.yatsergray.backend.domain.type.band;

public enum ChatAccessRoleType {
    OWNER,
    ADMIN,
    MEMBER
}
