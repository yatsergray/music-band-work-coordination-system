package ua.yatsergray.backend.exception.band;

public class ParticipationStatusAlreadyExistsException extends Exception {

    public ParticipationStatusAlreadyExistsException(String message) {
        super(message);
    }
}
