package ua.yatsergray.backend.exception.song;

public class SongPartDetailsAlreadyExistsException extends Exception {

    public SongPartDetailsAlreadyExistsException(String message) {
        super(message);
    }
}
