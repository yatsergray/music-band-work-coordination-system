package ua.yatsergray.backend.exception.band;

public class EventConflictException extends Exception {

    public EventConflictException(String message) {
        super(message);
    }
}
