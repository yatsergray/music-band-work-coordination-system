package ua.yatsergray.backend.exception.band;

public class NoSuchChatException extends Exception {

    public NoSuchChatException(String message) {
        super(message);
    }
}
