package ua.yatsergray.backend.exception.song;

public class SongCategoryAlreadyExistsException extends Exception {

    public SongCategoryAlreadyExistsException(String message) {
        super(message);
    }
}
