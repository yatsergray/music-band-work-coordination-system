package ua.yatsergray.backend.exception.band;

public class NoSuchEventException extends Exception {

    public NoSuchEventException(String message) {
        super(message);
    }
}
