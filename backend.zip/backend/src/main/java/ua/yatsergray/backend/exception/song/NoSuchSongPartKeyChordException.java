package ua.yatsergray.backend.exception.song;

public class NoSuchSongPartKeyChordException extends Exception {

    public NoSuchSongPartKeyChordException(String message) {
        super(message);
    }
}
