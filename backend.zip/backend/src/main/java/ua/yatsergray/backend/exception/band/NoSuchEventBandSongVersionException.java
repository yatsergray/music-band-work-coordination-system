package ua.yatsergray.backend.exception.band;

public class NoSuchEventBandSongVersionException extends Exception {

    public NoSuchEventBandSongVersionException(String message) {
        super(message);
    }
}
