package ua.yatsergray.backend.exception.song;

public class ChordAlreadyExistsException extends Exception {

    public ChordAlreadyExistsException(String message) {
        super(message);
    }
}
