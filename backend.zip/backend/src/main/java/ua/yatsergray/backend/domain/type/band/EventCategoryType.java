package ua.yatsergray.backend.domain.type.band;

public enum EventCategoryType {
    MUSICIANS_REHEARSAL,
    VOCALISTS_REHEARSAL,
    DRESS_REHEARSAL,
    ROUGH_REHEARSAL,
    PERFORMANCE
}
