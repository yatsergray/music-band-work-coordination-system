package ua.yatsergray.backend.exception.band;

public class BandUserConflictException extends Exception {

    public BandUserConflictException(String message) {
        super(message);
    }
}
