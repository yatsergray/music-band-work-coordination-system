package ua.yatsergray.backend.exception.song;

public class NoSuchSongMoodException extends Exception {

    public NoSuchSongMoodException(String message) {
        super(message);
    }
}
