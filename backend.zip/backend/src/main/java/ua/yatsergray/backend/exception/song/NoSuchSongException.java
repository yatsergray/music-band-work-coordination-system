package ua.yatsergray.backend.exception.song;

public class NoSuchSongException extends Exception {

    public NoSuchSongException(String message) {
        super(message);
    }
}
