package ua.yatsergray.backend.exception.band;

public class ChatAlreadyExistsException extends Exception {

    public ChatAlreadyExistsException(String message) {
        super(message);
    }
}
