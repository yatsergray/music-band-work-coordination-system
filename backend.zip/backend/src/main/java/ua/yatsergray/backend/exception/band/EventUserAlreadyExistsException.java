package ua.yatsergray.backend.exception.band;

public class EventUserAlreadyExistsException extends Exception {

    public EventUserAlreadyExistsException(String message) {
        super(message);
    }
}
