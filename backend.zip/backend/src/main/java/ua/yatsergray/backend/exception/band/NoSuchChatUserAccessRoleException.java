package ua.yatsergray.backend.exception.band;

public class NoSuchChatUserAccessRoleException extends Exception {

    public NoSuchChatUserAccessRoleException(String message) {
        super(message);
    }
}