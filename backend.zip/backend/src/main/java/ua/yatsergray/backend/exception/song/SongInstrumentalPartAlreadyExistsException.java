package ua.yatsergray.backend.exception.song;

public class SongInstrumentalPartAlreadyExistsException extends Exception {

    public SongInstrumentalPartAlreadyExistsException(String message) {
        super(message);
    }
}
