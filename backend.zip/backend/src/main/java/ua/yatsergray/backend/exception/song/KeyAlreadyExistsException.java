package ua.yatsergray.backend.exception.song;

public class KeyAlreadyExistsException extends Exception {

    public KeyAlreadyExistsException(String message) {
        super(message);
    }
}
