package ua.yatsergray.backend.exception.band;

public class NoSuchEventUserException extends Exception {

    public NoSuchEventUserException(String message) {
        super(message);
    }
}
