package ua.yatsergray.backend.exception.band;

public class NoSuchStageRoleException extends Exception {

    public NoSuchStageRoleException(String message) {
        super(message);
    }
}
