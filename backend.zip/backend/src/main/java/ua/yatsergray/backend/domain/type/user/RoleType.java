package ua.yatsergray.backend.domain.type.user;

public enum RoleType {
    ADMIN,
    USER
}
