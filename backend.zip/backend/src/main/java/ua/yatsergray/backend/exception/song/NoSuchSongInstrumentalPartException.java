package ua.yatsergray.backend.exception.song;

public class NoSuchSongInstrumentalPartException extends Exception {

    public NoSuchSongInstrumentalPartException(String message) {
        super(message);
    }
}
