package ua.yatsergray.backend.exception;

public class ChildEntityExistsException extends Exception {

    public ChildEntityExistsException(String message) {
        super(message);
    }
}
