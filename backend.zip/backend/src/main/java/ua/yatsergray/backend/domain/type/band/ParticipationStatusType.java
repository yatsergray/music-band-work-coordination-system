package ua.yatsergray.backend.domain.type.band;

public enum ParticipationStatusType {
    ACCEPTED,
    PENDING,
    REJECTED
}
