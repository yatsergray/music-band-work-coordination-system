package ua.yatsergray.backend.exception.song;

public class NoSuchChordException extends Exception {

    public NoSuchChordException(String message) {
        super(message);
    }
}
