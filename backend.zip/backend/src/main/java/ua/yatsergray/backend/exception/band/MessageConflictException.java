package ua.yatsergray.backend.exception.band;

public class MessageConflictException extends Exception {

    public MessageConflictException(String message) {
        super(message);
    }
}
