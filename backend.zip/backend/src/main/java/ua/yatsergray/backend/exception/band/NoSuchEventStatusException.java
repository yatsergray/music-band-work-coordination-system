package ua.yatsergray.backend.exception.band;

public class NoSuchEventStatusException extends Exception {

    public NoSuchEventStatusException(String message) {
        super(message);
    }
}
