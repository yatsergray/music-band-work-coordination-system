package ua.yatsergray.backend.domain.type.song;

public enum SongPartCategoryType {
    VERSE,
    CHORUS,
    REFRAIN,
    BRIDGE,
    ENDING
}
