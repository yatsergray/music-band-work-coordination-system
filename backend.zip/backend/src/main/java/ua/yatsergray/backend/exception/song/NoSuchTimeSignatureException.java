package ua.yatsergray.backend.exception.song;

public class NoSuchTimeSignatureException extends Exception {

    public NoSuchTimeSignatureException(String message) {
        super(message);
    }
}
