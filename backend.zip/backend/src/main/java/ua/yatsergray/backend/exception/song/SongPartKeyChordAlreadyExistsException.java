package ua.yatsergray.backend.exception.song;

public class SongPartKeyChordAlreadyExistsException extends Exception {

    public SongPartKeyChordAlreadyExistsException(String message) {
        super(message);
    }
}
