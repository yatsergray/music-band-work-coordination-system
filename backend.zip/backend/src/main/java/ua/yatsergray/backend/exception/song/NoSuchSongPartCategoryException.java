package ua.yatsergray.backend.exception.song;

public class NoSuchSongPartCategoryException extends Exception {

    public NoSuchSongPartCategoryException(String message) {
        super(message);
    }
}
