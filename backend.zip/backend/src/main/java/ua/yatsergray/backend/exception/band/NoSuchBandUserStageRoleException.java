package ua.yatsergray.backend.exception.band;

public class NoSuchBandUserStageRoleException extends Exception {

    public NoSuchBandUserStageRoleException(String message) {
        super(message);
    }
}
