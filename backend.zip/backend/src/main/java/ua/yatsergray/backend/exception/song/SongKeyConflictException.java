package ua.yatsergray.backend.exception.song;

public class SongKeyConflictException extends Exception {

    public SongKeyConflictException(String message) {
        super(message);
    }
}
