package ua.yatsergray.backend.exception.band;

public class EventRoomConflictException extends Exception {

    public EventRoomConflictException(String message) {
        super(message);
    }
}
