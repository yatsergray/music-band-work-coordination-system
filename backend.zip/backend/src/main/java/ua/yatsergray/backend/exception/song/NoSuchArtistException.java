package ua.yatsergray.backend.exception.song;

public class NoSuchArtistException extends Exception {

    public NoSuchArtistException(String message) {
        super(message);
    }
}
