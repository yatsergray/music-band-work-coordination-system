package ua.yatsergray.backend.exception.band;

public class InvitationAlreadyExistsException extends Exception {

    public InvitationAlreadyExistsException(String message) {
        super(message);
    }
}
