package ua.yatsergray.backend.exception.band;

public class NoSuchBandSongVersionException extends Exception {

    public NoSuchBandSongVersionException(String message) {
        super(message);
    }
}
