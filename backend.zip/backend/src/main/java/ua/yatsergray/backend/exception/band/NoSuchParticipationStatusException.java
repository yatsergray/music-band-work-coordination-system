package ua.yatsergray.backend.exception.band;

public class NoSuchParticipationStatusException extends Exception {

    public NoSuchParticipationStatusException(String message) {
        super(message);
    }
}
