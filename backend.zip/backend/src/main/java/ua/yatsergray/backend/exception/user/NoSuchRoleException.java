package ua.yatsergray.backend.exception.user;

public class NoSuchRoleException extends Exception {

    public NoSuchRoleException(String message) {
        super(message);
    }
}
