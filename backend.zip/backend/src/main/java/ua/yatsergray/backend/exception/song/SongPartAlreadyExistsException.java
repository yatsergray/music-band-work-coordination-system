package ua.yatsergray.backend.exception.song;

public class SongPartAlreadyExistsException extends Exception {

    public SongPartAlreadyExistsException(String message) {
        super(message);
    }
}
