package ua.yatsergray.backend.exception.band;

public class ChatUserConflictException extends Exception {

    public ChatUserConflictException(String message) {
        super(message);
    }
}
