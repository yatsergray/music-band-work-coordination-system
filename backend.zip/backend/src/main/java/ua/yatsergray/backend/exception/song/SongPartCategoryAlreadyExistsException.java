package ua.yatsergray.backend.exception.song;

public class SongPartCategoryAlreadyExistsException extends Exception {

    public SongPartCategoryAlreadyExistsException(String message) {
        super(message);
    }
}
