package ua.yatsergray.backend.exception.band;

public class NoSuchBandUserAccessRoleException extends Exception {

    public NoSuchBandUserAccessRoleException(String message) {
        super(message);
    }
}
