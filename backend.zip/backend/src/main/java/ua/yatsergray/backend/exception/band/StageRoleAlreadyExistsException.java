package ua.yatsergray.backend.exception.band;

public class StageRoleAlreadyExistsException extends Exception {

    public StageRoleAlreadyExistsException(String message) {
        super(message);
    }
}
