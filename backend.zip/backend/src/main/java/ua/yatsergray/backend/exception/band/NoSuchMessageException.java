package ua.yatsergray.backend.exception.band;

public class NoSuchMessageException extends Exception {

    public NoSuchMessageException(String message) {
        super(message);
    }
}
