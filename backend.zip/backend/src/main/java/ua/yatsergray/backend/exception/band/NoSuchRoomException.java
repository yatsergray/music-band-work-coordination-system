package ua.yatsergray.backend.exception.band;

public class NoSuchRoomException extends Exception {

    public NoSuchRoomException(String message) {
        super(message);
    }
}
