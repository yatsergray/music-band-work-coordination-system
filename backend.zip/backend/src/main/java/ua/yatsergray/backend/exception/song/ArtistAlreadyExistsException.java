package ua.yatsergray.backend.exception.song;

public class ArtistAlreadyExistsException extends Exception {

    public ArtistAlreadyExistsException(String message) {
        super(message);
    }
}
