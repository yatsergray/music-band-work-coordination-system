package ua.yatsergray.backend.exception.band;

public class InvitationConflictException extends Exception {

    public InvitationConflictException(String message) {
        super(message);
    }
}
