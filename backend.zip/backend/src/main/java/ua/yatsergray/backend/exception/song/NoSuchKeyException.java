package ua.yatsergray.backend.exception.song;

public class NoSuchKeyException extends Exception {

    public NoSuchKeyException(String message) {
        super(message);
    }
}
