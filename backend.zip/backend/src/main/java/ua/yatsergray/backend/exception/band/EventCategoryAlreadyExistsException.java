package ua.yatsergray.backend.exception.band;

public class EventCategoryAlreadyExistsException extends Exception {

    public EventCategoryAlreadyExistsException(String message) {
        super(message);
    }
}
