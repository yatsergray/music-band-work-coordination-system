package ua.yatsergray.backend.exception.song;

public class SongMoodAlreadyExistsException extends Exception {

    public SongMoodAlreadyExistsException(String message) {
        super(message);
    }
}
