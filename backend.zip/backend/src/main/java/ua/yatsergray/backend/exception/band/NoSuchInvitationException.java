package ua.yatsergray.backend.exception.band;

public class NoSuchInvitationException extends Exception {

    public NoSuchInvitationException(String message) {
        super(message);
    }
}
