package ua.yatsergray.backend.domain.type.band;

public enum BandAccessRoleType {
    OWNER,
    ADMIN,
    MEMBER
}
