package ua.yatsergray.backend.exception.band;

public class NoSuchBandAccessRoleException extends Exception {

    public NoSuchBandAccessRoleException(String message) {
        super(message);
    }
}
