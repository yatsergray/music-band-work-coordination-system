package ua.yatsergray.backend.domain.type.band;

public enum EventStatusType {
    IN_DRAFT,
    PUBLISHED
}
