package ua.yatsergray.backend.exception.band;

public class RoomAlreadyExistsException extends Exception {

    public RoomAlreadyExistsException(String message) {
        super(message);
    }
}
