package ua.yatsergray.backend.exception.band;

public class NoSuchEventCategoryException extends Exception {

    public NoSuchEventCategoryException(String message) {
        super(message);
    }
}
