package ua.yatsergray.backend.exception.band;

public class NoSuchBandException extends Exception {

    public NoSuchBandException(String message) {
        super(message);
    }
}
