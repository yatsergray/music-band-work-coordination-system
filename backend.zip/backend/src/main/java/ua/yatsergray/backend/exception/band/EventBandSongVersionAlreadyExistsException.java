package ua.yatsergray.backend.exception.band;

public class EventBandSongVersionAlreadyExistsException extends Exception {

    public EventBandSongVersionAlreadyExistsException(String message) {
        super(message);
    }
}
