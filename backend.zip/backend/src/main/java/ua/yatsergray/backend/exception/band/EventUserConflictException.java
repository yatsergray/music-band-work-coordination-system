package ua.yatsergray.backend.exception.band;

public class EventUserConflictException extends Exception {

    public EventUserConflictException(String message) {
        super(message);
    }
}
