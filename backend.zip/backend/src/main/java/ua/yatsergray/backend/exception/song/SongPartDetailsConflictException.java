package ua.yatsergray.backend.exception.song;

public class SongPartDetailsConflictException extends Exception {

    public SongPartDetailsConflictException(String message) {
        super(message);
    }
}
