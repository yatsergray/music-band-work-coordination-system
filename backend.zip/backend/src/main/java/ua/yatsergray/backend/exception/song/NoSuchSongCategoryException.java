package ua.yatsergray.backend.exception.song;

public class NoSuchSongCategoryException extends Exception {

    public NoSuchSongCategoryException(String message) {
        super(message);
    }
}
