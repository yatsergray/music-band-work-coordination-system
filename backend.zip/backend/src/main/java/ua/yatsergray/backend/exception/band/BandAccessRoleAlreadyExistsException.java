package ua.yatsergray.backend.exception.band;

public class BandAccessRoleAlreadyExistsException extends Exception {

    public BandAccessRoleAlreadyExistsException(String message) {
        super(message);
    }
}
