package ua.yatsergray.backend.exception.song;

public class NoSuchSongPartException extends Exception {

    public NoSuchSongPartException(String message) {
        super(message);
    }
}
