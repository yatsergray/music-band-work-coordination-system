package ua.yatsergray.backend.exception.band;

public class ChatAccessRoleAlreadyExistsException extends Exception {

    public ChatAccessRoleAlreadyExistsException(String message) {
        super(message);
    }
}
